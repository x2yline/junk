DNAMAN v5.2.2 full: Integrated System for Sequence Analysis
for detail, plz visit:
http://www.lynnon.com

install:
=========
input anything you like to reg it

@7Dream

Nov. 22, 2002