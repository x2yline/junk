######Video source: https://shop119322454.taobao.com
#source("http://bioconductor.org/biocLite.R")
#biocLite("clusterProfiler")
#biocLite("pathview")

setwd("C:/Users/DELL/Desktop/KEGG/kegg1")
library("clusterProfiler")
rt=read.table("input.txt",sep="\t",header=T,check.names=F)
geneFC=rt$logFC
gene <- rt$ENTREZ_GENE_ID
names(geneFC)=gene

#kegg
kk <- enrichKEGG(gene = gene, organism = "human", qvalueCutoff = 0.05, readable = TRUE)
write.table(summary(kk),file="KEGG.xls",sep="\t",quote=F,row.names = F)
pdf(file="KEGG.barplot.pdf")
barplot(kk, drop = TRUE, showCategory = 12)
pdf(file="KEGG.cnetplot.pdf")
cnetplot(kk, categorySize = "geneNum", foldChange = geneFC)
library("pathview")
keggxls=read.table("KEGG.xls",sep="\t",header=T)
for(i in keggxls$ID){
pv.out <- pathview(gene.data = geneFC, pathway.id = i, species = "hsa", out.suffix = "pathview")}
